
package com.cg.project.controllers;

import java.util.List;

public class UserBean {


	private int associateId;
	private String Password,firstName,lastName,emailId,mobileNo,gender;
	List<String> communication;
	public UserBean() {
	}
	
	public UserBean(int associateId, String password) {
		super();
		this.associateId = associateId;
		Password = password;
	}

	public UserBean(int associateId, String password, String firstName, String lastName, String emailId,
			String mobileNo, String gender, List<String> communication) {
		super();
		this.associateId = associateId;
		Password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.gender = gender;
		this.communication = communication;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public List<String> getCommunication() {
		return communication;
	}
	public void setCommunication(List<String> communication) {
		this.communication = communication;
	}
	
	

}
