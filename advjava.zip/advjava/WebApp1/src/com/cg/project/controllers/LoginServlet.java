package com.cg.project.controllers;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		int associateID=Integer.parseInt(request.getParameter("AssociateID"));
		String Password=request.getParameter("password");
		
	/*	out.println("<html><body>");
		out.println("<div background='blue'>");
		if(associateId==111&&Password.equals("Madhu"))
			out.print("<font color='green'> Welcome associate in WebPortal</font>");
			else
			out.print("<font color='red'> associateId or password is wrong</font>");
		out.println("</div");
		out.println("</body></html>");*/
		
		UserBean bean=new UserBean(associateID,Password);
		RequestDispatcher dispatcher=null;
		if(bean.getAssociateId()==1111&&bean.getPassword().equals("Madhu")) {
		dispatcher=request.getRequestDispatcher("LoginSuccess.jsp");
		request.setAttribute("bean",bean);
		dispatcher.forward(request,response);
	
	}else {
		dispatcher=request.getRequestDispatcher("LoginPage.jsp");
		request.setAttribute("error","Id or Password is wromg");
		dispatcher.forward(request,response);
	
	}
}
}