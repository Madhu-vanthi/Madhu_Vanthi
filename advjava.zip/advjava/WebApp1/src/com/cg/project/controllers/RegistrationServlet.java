package com.cg.project.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out=response.getWriter();
		String FirstName=request.getParameter("FirstName");
		String LastName=request.getParameter("LastName");
		String EmailId=request.getParameter("EmailId");
		String Department=request.getParameter("Department");
		String Password=request.getParameter("password");
		String Gender=request.getParameter("gender");
		String Graduation=request.getParameter("graduation");
		String Communication=request.getParameter("communication");
		List<String> communicationList=new ArrayList<>(Arrays.asList(Communication));

		/*String Designation=request.getParameter("Designation");
		String pancard=request.getParameter("pancard");
		String YearlyInvestmentUnder80c=request.getParameter("YearlyInvestmentUnder80c");
		String BasicSalary=request.getParameter("BasicSalary");
		String BankName=request.getParameter("BankName");
		String Accountnumber=request.getParameter("Accountnumber:");
		String IFSCCode=request.getParameter("IFSCCode:");
*/
		out.println("<html><body>");
		out.println("<div background='blue'>");
	out.println("firstName:"+FirstName+"</br>"+"lastname"+LastName+"</br>"+"EmailId"+EmailId+"</br>"
		+"Department"+Department);
		out.println("</div");
		out.println("</body></html>");
	}

}
