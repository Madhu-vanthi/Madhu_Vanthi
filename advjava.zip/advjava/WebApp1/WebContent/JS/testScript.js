/*(for(var a=1 ; a<=10 ; a++){
document.write("Welcome!!!!!<br/>");
console.log("Welcome!!!!!!!");
}
*/
function callForWork(){
	alert("alert box message");
	document.write("Hello World");
}
function addNumber(){
	var n1=parseInt(document.mathFrm.num1.value);
	var n2=parseInt(document.mathFrm.num2.value);
	var n3=n1+n2;
	document.mathFrm.ans.value=n3;
}