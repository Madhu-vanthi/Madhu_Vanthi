function validateRegistrationForm(){
	if (registrationForm.FirstName.value==""){
		alert("Enter First Name");
		return false;
	}
	else if (registrationForm.LastName.value==""){
		alert("Enter Last Name");
		return false;
	}
	else if (registrationForm.EmailId.value==""){
		alert("Enter emailId");
		return false;
	}
	else if (registrationForm.Department.value==""){
		alert("Enter department");
		return false;
	}
	else if (registrationForm.Designation.value==""){
		alert("Enter designation");
		return false;
	}
	else if (registrationForm.pancard.value==""){
		alert("Enter PAN Number");
		return false;
	}
	else if (registrationForm.YearlyInvestmentUnder80c.value==""){
		alert("Enter YearlIinvestment(80c)");
		return false;
	}
	else if (registrationForm.BasicSalary.value==""){
		alert("Enter BasicSalary");
		return false;
	}
	else if (registrationForm.BankName.value==""){
		alert("Enter BankName");
		return false;
	}
	else if (registrationForm.Accountnumber.value==""){
		alert("Enter AccountNumber");
		return false;
	}
	else if (registrationForm.IFSCCode.value==""){
		alert("Enter IFSCCode");
		return false;
	}}