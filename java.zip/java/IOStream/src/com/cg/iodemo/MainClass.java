package com.cg.iodemo;

import java.io.File;
import java.io.IOException;

public class MainClass {

	public static void main(String[] args) {
		try{
			File file=new File("D:\\AssociateData.txt");
		ObjectSerializationDemo.doSerialization(file);
		
		ObjectSerializationDemo.doDeSerialization(file);
	}	
	catch(IOException | ClassNotFoundException e)
	{
		e.printStackTrace();
	}

}
}
