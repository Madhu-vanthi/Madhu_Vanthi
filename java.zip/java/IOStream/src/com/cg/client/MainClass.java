package com.cg.client;

import java.io.File;
import java.io.IOException;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	File file=new File("d:\\datafile.txt");
	try {
		file.createNewFile();
} 
catch (IOException e) {
	e.printStackTrace();
}
System.out.println(file.canWrite());
System.out.println(file.getName());
	System.out.println(file.canExecute());
	}
	}

