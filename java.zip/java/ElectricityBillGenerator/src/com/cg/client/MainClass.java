package com.cg.client;

import com.cg.Ebill.beans.Customer;
import com.cg.Ebill.daoServices.CustomerDAO;

public class MainClass {

	public static void main(String[] args) {
		Customer customer=new Customer();
		
		
		
	}

}
