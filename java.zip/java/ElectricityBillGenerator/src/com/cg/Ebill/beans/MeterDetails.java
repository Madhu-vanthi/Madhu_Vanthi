package com.cg.Ebill.beans;

public class MeterDetails {
	private String meterNo, consumptionUnits, phase, meterload;
	private BillDetails billDetails;
	public MeterDetails() {
	}
	
	public MeterDetails(String meterNo, String consumptionUnits, String phase, String meterload,
			BillDetails billDetails) {
		super();
		this.meterNo = meterNo;
		this.consumptionUnits = consumptionUnits;
		this.phase = phase;
		this.meterload = meterload;
		this.billDetails = billDetails;
	}

	public MeterDetails(String meterNo, String consumptionUnits, String phase, String meterload) {
		super();
		this.meterNo = meterNo;
		this.consumptionUnits = consumptionUnits;
		this.phase = phase;
		this.meterload = meterload;
	}

	public String getMeterNo() {
		return meterNo;
	}

	public void setMeterNo(String meterNo) {
		this.meterNo = meterNo;
	}

	public String getConsumptionUnits() {
		return consumptionUnits;
	}

	public void setConsumptionUnits(String consumptionUnits) {
		this.consumptionUnits = consumptionUnits;
	}

	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public String getMeterload() {
		return meterload;
	}

	public void setMeterload(String meterload) {
		this.meterload = meterload;
	}

	public BillDetails getBillDetails() {
		return billDetails;
	}

	public void setBillDetails(BillDetails billDetails) {
		this.billDetails = billDetails;
	}

	@Override
	public String toString() {
		return "MeterDetails [meterNo=" + meterNo + ", consumptionUnits=" + consumptionUnits + ", phase=" + phase
				+ ", meterload=" + meterload + ", billDetails=" + billDetails + "]";
	}


}
