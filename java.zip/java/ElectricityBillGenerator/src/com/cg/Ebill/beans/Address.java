package com.cg.Ebill.beans;

public class Address {
private String street,locality,district,state;
public Address() {
}
public Address(String street, String locality, String district, String state) {
	super();
	this.street = street;
	this.locality = locality;
	this.district = district;
	this.state = state;
}
public String getStreet() {
	return street;
}
public void setStreet(String street) {
	this.street = street;
}
public String getLocality() {
	return locality;
}
public void setLocality(String locality) {
	this.locality = locality;
}
public String getDistrict() {
	return district;
}
public void setDistrict(String district) {
	this.district = district;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
@Override
public String toString() {
	return "Address [street=" + street + ", locality=" + locality + ", district=" + district + ", state=" + state + "]";
}

}
