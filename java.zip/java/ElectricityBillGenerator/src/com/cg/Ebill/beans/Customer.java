package com.cg.Ebill.beans;

public class Customer {
private String customerNo,mobileNo,firstName,lastName,panCard,emaiId;
private Address address;
private MeterDetails meter;
public Customer() {

}
public Customer(String customerNo, String mobileNo, String firstName, String lastName, String panCard,
		String emaiId, Address address, MeterDetails meter) {
	super();
	this.customerNo = customerNo;
	this.mobileNo = mobileNo;
	this.firstName = firstName;
	this.lastName = lastName;
	this.panCard = panCard;
	this.emaiId = emaiId;
	this.address = address;
	this.meter = meter;
}
public Customer(String customerNo, String mobileNo, String firstName, String lastName, String panCard,
		String emaiId) {
	super();
	this.customerNo = customerNo;
	this.mobileNo = mobileNo;
	this.firstName = firstName;
	this.lastName = lastName;
	this.panCard = panCard;
	this.emaiId = emaiId;
}
public String getCustomerName() {
	return customerNo;
}
public void setCustomerNo(String customerNo) {
	this.customerNo = customerNo;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getPanCard() {
	return panCard;
}
public void setPanCard(String panCard) {
	this.panCard = panCard;
}
public String getEmaiId() {
	return emaiId;
}
public void setEmaiId(String emaiId) {
	this.emaiId = emaiId;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
public MeterDetails getMeter() {
	return meter;
}
public void setMeter(MeterDetails meter) {
	this.meter = meter;
}
@Override
public String toString() {
	return "CustomerDetails [customerNo=" + customerNo + ", mobileNo=" + mobileNo + ", firstName=" + firstName
			+ ", lastName=" + lastName + ", panCard=" + panCard + ", emaiId=" + emaiId + ", address=" + address
			+ ", meter=" + meter + "]";
}

}
