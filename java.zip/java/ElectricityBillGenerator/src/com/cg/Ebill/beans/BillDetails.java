package com.cg.Ebill.beans;

public class BillDetails {
  private String billNo, billDuedate, billAmonut,billUnit,billMonth;
  public BillDetails() {  
  }
public BillDetails(String billNo, String billDuedate, String billAmonut, String billUnit, String billMonth) {
	super();
	this.billNo = billNo;
	this.billDuedate = billDuedate;
	this.billAmonut = billAmonut;
	this.billUnit = billUnit;
	this.billMonth = billMonth;
}
public String getBillNo() {
	return billNo;
}
public void setBillNo(String billNo) {
	this.billNo = billNo;
}
public String getBillDuedate() {
	return billDuedate;
}
public void setBillDuedate(String billDuedate) {
	this.billDuedate = billDuedate;
}
public String getBillAmonut() {
	return billAmonut;
}
public void setBillAmonut(String billAmonut) {
	this.billAmonut = billAmonut;
}
public String getBillUnit() {
	return billUnit;
}
public void setBillUnit(String billUnit) {
	this.billUnit = billUnit;
}
public String getBillMonth() {
	return billMonth;
}
public void setBillMonth(String billMonth) {
	this.billMonth = billMonth;
}
@Override
public String toString() {
	return "BillDetails [billNo=" + billNo + ", billDuedate=" + billDuedate + ", billAmonut=" + billAmonut
			+ ", billUnit=" + billUnit + ", billMonth=" + billMonth + "]";
}  
    
}
