package com.cg.Ebill.utill;
import java.util.HashMap;
import com.cg.Ebill.beans.Customer;

public class ElectricityBillUtil {
private static int CUSTOMER_ID_COUNTER=0;
public static HashMap<Integer, Customer> customer=new HashMap<>();
public static int getCUSTOMER_ID_COUNTER() {
	return ++CUSTOMER_ID_COUNTER;
}
}
