package com.cg.Ebill.daoServices;

import java.util.List;

import com.cg.Ebill.beans.Customer;

public interface CustomerDAO {
	Customer save(Customer customer);
	boolean update(Customer customer);
	Customer findOne(int AssociateId);
	List<Customer>  findAll();

}
