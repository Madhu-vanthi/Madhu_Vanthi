package com.cg.Ebill.daoServices;

import java.util.List;

import com.cg.Ebill.beans.Customer;

public  class CustomerDAOImpl implements CustomerDAO {

	@Override
	public Customer save(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer findOne(int AssociateId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
