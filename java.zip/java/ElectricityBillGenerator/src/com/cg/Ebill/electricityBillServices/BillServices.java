package com.cg.Ebill.electricityBillServices;

import java.util.List;
import com.c 
import com.cg.Ebill.beans.Address;
import com.cg.Ebill.beans.BillDetails;
import com.cg.Ebill.beans.Customer;
import com.cg.Ebill.beans.MeterDetails;

public interface BillServices {
int acceptCustomerDetsils(String customerNo, String mobileNo, String firstName, String lastName, String panCard,
		String emaiId, String street, String locality, String district, String state, String meterNo, String consumptionUnits, String phase, String meterload,
		BillDetails billDetails);
int calculateNetSalary(int associateId)throws BillDetailsNotFoundException;
Customer getCustomerDetails(int customerNo)throws BillDetailsNotFoundEXception;
List<Customer> getAllAssociateDeatils();
}
