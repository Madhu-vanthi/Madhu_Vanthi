package com.cg.client;

import com.cg.beans.*;
public class MainClass {
	public static void main(String[] args) {
	Employee emp;
	emp=new PEmployee(112,15000,"Aanchal","S");
	emp.calculateSalary();
	System.out.println(emp.getEmployeeId()+" "+emp.getFirstName()+" "+emp.getLastName()+" "+emp.getTotalSalary());
	
	emp=new CEmployee(113,"gopi","A",50);
	((CEmployee) emp).signContract();
	emp.calculateSalary();
	System.out.println(emp.getEmployeeId()+" "+emp.getFirstName()+" "+emp.getLastName()+" "+emp.getTotalSalary());
	
		emp=new SalesManager(986,5452,"jhgwq","wshdxiu",55);
		emp.calculateSalary();
		System.out.println(emp.getEmployeeId()+" "+emp.getFirstName()+" "+emp.getLastName()+" "+emp.getTotalSalary());
	}
}
