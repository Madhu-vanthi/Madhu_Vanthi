package com.cg.beans;

public final class SalesManager extends PEmployee{
	
	private int noOfProjects, commission;
	public SalesManager() {
	super();
	}
	 
public SalesManager(int employeeId,  int basicSalary,String firstName, String lastName,int noOfProjects)
{
	super(employeeId,basicSalary,firstName,lastName);
}

public int getNoOfProjects() {
	return noOfProjects;
}

public void setNoOfProjects(int noOfProjects) {
	this.noOfProjects = noOfProjects;
}

public int getCommission() {
	return commission;
}

public void setCommission(int commission) {
	this.commission = commission;
}

@Override
public void calculateSalary() {
	commission=noOfProjects*2000;
	super.calculateSalary();
setTotalSalary(getTotalSalary()+commission);
}

}
