package com.cg.beans;

public final class CEmployee extends Employee {

	private int hrs,variablePay;
	public CEmployee()
	{
	super();
	}
	public CEmployee(int employeeId,String firstName,String lastName, int hrs)
	{
		super(employeeId,firstName,lastName);
		this.hrs=hrs;
	}
	
	public int getHrs() {
		return hrs;
	}
	public void setHrs(int hrs) {
		this.hrs = hrs;
	}
	public void calculateSalary() {
		variablePay=hrs*500;
		setTotalSalary(variablePay);
	}
	public void signContract()
	{
		System.out.println("contract has signed");
	}
}
