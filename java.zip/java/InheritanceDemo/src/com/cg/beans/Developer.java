package com.cg.beans;

public final class Developer extends PEmployee{
	
	private int noOfProjects, incentives;
	public Developer() {
	super();
	}
	 
public Developer(int employeeId,  int basicSalary,String firstName, String lastName,int noOfProjects)
{
	super(employeeId,basicSalary,firstName,lastName);
}

public int getNoOfProjects() {
	return noOfProjects;
}

public void setNoOfProjects(int noOfProjects) {
	this.noOfProjects = noOfProjects;
}

public int getIncentives() {
	return incentives;
}

public void setIncentives(int incentives) {
	this.incentives = incentives;
}

@Override
public void calculateSalary() {
	incentives=noOfProjects*2000;
	super.calculateSalary();
setTotalSalary(getTotalSalary()+incentives);
}

}
