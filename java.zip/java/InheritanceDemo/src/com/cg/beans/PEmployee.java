package com.cg.beans;

public class PEmployee  extends  Employee{
	
	private int hra,pa,ca;
	
	PEmployee(){
		super();
	}
	
	public PEmployee(int employeeId, int basicSalary,String firstName, String lastName) {
	super(employeeId,basicSalary,firstName,lastName);
}

	public PEmployee(int hra, int pa, int ca) {
		super();
		this.hra = hra;
		this.pa = pa;
		this.ca = ca;
	}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getPa() {
		return pa;
	}

	public void setPa(int pa) {
		this.pa = pa;
	}

	public int getCa() {
		return ca;
	}

	public void setCa(int ca) {
		this.ca = ca;
	}
public	void calculateSalary() {
		hra=this.getBasicSalary()*10/100;
		pa=this.getBasicSalary()*10/100;
		ca=this.getBasicSalary();
		this.setTotalSalary(this.getBasicSalary()+hra+pa+ca);
	}
}