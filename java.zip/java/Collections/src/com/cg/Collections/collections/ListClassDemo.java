package com.cg.Collections.collections;

import java.util.List;
import java.util.ArrayList;

import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.locks.Condition;
import java.util.function.Predicate;
import java.util.stream.Stream;

import com.cg.Collections.beans.Associate;

public class ListClassDemo {
  public static void ArrayListClassDemo(){
	ArrayList<Associate> associates=new ArrayList<>();
	//inserting
	associates.add(new Associate(111,20000,"madhu","geethu"));
	associates.add(new Associate(112,30000,"preethi","SR"));
	associates.add(new Associate(117,20000,"Aanchal","S"));
	associates.add(new Associate(115,20000,"Gopi","A"));
	associates.add(new Associate(116,20000,"Lakshmi","C"));

	Stream<Associate> stream1=associates.stream();
	Stream<Associate> stream2=stream1.distinct();
	Stream<Associate> stream3=stream2.filter((associate)->associates.getFirstName().startsWith("N"));
	//searching	
	Associate associateToBeSearch=new Associate(112,30000,"preethi","SR");
	int idx=associates.indexOf(associateToBeSearch);
	System.out.println(idx);
  
  /*//remove
  associates.remove(1);
  
  //sort
  Collections.sort(associates);
  System.out.println(associates);
  */
  Comparator<Associate> assComparator=(a1,a2)->a1.getBasicSalary()-a2.getBasicSalary();
  Collections.sort(associates,(a1,a2)->a1.getBasicSalary()-a2.getBasicSalary());

	printAssociateDetails(associates,ass->ass.getName().startsWith("a"));
	private static void printEmployeeDetails1(List<Associate> associates1,Condition condition) {
        for (Associate associate : associates1) {
            if (condition.startWith(associate))
                System.out.println(associates);
        }
    }
    private static void printEmployeeDetails2(List<Associate> associates1,Predicate<Associate>predicate,Consumer<Associate>consumer){
        for (Associate associate : associates1) {
            if(predicate.test(associate))
                consumer.accept(associate);
        }

    }
	
	
  }
	
	
	
/*        associates1.stream().distinct().filter((a)->a.getFirstName().startsWith("g")).forEach((a)->System.out.println(a));
        System.out.println(associates1.stream().map(associate->associate.getAssociateId()));
        
    }
    /*private static void printEmployeeDetails1(List<Associate> associates1,Condition condition) {
        for (Associate associate : associates1) {
            if (condition.startWith(associate))
                System.out.println(associate);
        }
    }
    private static void printEmployeeDetails2(List<Associate> associates1,Predicate<Associate>predicate,Consumer<Associate>consumer){
        for (Associate associate : associates1) {
            if(predicate.test(associate))
                consumer.accept(associate);
        }

    }*/
}

*/
