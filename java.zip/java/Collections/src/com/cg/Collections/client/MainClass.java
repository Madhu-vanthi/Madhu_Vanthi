package com.cg.Collections.client;

import com.cg.Collections.collections.ListClassDemo;

public class MainClass {

	public static void main(String[] args) {

		ListClassDemo.ArrayListClassDemo();
		
			}

}
