package com.cg.Collections.beans;

import java.util.Comparator;

public class AssociateComparator implements  Comparator<Associate>{

	

	@Override
	public int compare(Associate associate1, Associate associate2) {
		// TODO Auto-generated method stub
		return associate1.compareTo(associate1);
	}

}
