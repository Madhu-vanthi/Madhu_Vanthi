package com.cg.bank.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.bank.customer.Customer;
import com.cg.bank.util.BankUtil;

public class CustomerDaoImpl implements CustomerDao{

	@Override
	public Customer save(Customer customer) {
		customer.setCustomerID(BankUtil.getCUSTOMER_ID_COUNTER());
	BankUtil.customers.put(customer.getCustomerID(), customer);
		return customer;
	}

	@Override
	public boolean update(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer findOne(int customerID) {
		return BankUtil.customers.get(customerID);
	
	}

	@Override
	public List<Customer> findAll() {
		
		return new ArrayList<Customer>(BankUtil.customers.values());
	}
	
}
