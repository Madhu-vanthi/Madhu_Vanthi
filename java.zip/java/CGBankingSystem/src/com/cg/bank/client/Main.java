package com.cg.bank.client;
import com.cg.bank.customer.Account;
import com.cg.bank.customer.Customer;
import com.cg.bank.customernotfoundexception.CustomerNotFoundException;
import com.cg.bank.daoservices.CustomerDao;
import com.cg.bank.daoservices.CustomerDaoImpl;
import com.cg.bank.services.BankService;
import com.cg.bank.services.BankServicesImpl;
import com.cg.bank.util.BankUtil;
public class Main {
	public static void main(String[] args) {
		try {
		CustomerDao cd=new CustomerDaoImpl();
			BankService bankService=new BankServicesImpl();
			int customerID=bankService.acceptCustomerDetails(101, 564125, 584121, 4356, "Madhu	", "MV", "mv@gmail.com", "fh4", "Tirupur", "TN", "INDIA", 5451, 0, "saving");
			System.out.println("customer ID:"+customerID);
			Customer customer=bankService.getCustomerDetails(customerID);
			System.out.println(customer.toString());						
			int depositValue=bankService.deposit(10000, customerID);
			System.out.println("Deposit amount:"+depositValue);
			int withdrawValue=bankService.withDraw(5000, customerID);
			System.out.println("Withdraw amount:"+withdrawValue);
			int depositValue1=bankService.deposit(8000, customerID);
			int withdrawValue1=bankService.withDraw(4000, customerID);
			System.out.println("Withdraw amount:"+withdrawValue1);
			Customer c=cd.findOne(customerID);
			System.out.println("Orignal account balance :"+c.getAccount().getAccountBalance());
		} catch (CustomerNotFoundException e) {
			e.printStackTrace();
		}

	}

}