package com.cg.MobileBilling.beans;

public class PostPaidAccount {
private Bill bill;
private Plan plan;

}
