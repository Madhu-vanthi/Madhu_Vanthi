package com.cg.MobileBilling.beans;

public class Address {
private String city,state,pinCode,countryPostPaidAccount,mobileNo;
public Address() {
}
public Address(String city, String state, String pinCode, String countryPostPaidAccount, String mobileNo) {
	super();
	this.city = city;
	this.state = state;
	this.pinCode = pinCode;
	this.countryPostPaidAccount = countryPostPaidAccount;
	this.mobileNo = mobileNo;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getPinCode() {
	return pinCode;
}
public void setPinCode(String pinCode) {
	this.pinCode = pinCode;
}
public String getCountryPostPaidAccount() {
	return countryPostPaidAccount;
}
public void setCountryPostPaidAccount(String countryPostPaidAccount) {
	this.countryPostPaidAccount = countryPostPaidAccount;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}

}
