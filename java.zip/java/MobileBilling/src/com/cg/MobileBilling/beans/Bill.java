package com.cg.MobileBilling.beans;

public class Bill {
private int billID,noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls;
private float internetDataUsageUnits, internetDataUsageUnitsAmount, billMonth, stateGST, centralGST, totalBillAmount,
localSMSAount, stdSMSAmount,totalCallAmount;
public Bill() {
}
public Bill(int billID, int noOfLocalSMS, int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls,
		float internetDataUsageUnits, float internetDataUsageUnitsAmount, float billMonth, float stateGST,
		float centralGST, float totalBillAmount, float localSMSAount, float stdSMSAmount, float totalCallAmount) {
	super();
	this.billID = billID;
	this.noOfLocalSMS = noOfLocalSMS;
	this.noOfStdSMS = noOfStdSMS;
	this.noOfLocalCalls = noOfLocalCalls;
	this.noOfStdCalls = noOfStdCalls;
	this.internetDataUsageUnits = internetDataUsageUnits;
	this.internetDataUsageUnitsAmount = internetDataUsageUnitsAmount;
	this.billMonth = billMonth;
	this.stateGST = stateGST;
	this.centralGST = centralGST;
	this.totalBillAmount = totalBillAmount;
	this.localSMSAount = localSMSAount;
	this.stdSMSAmount = stdSMSAmount;
	this.totalCallAmount = totalCallAmount;
}
public float getBillID() {
	return billID;
}
public void setBillID(int billID) {
	this.billID = billID;
}
public float getNoOfLocalSMS() {
	return noOfLocalSMS;
}
public void setNoOfLocalSMS(int noOfLocalSMS) {
	this.noOfLocalSMS = noOfLocalSMS;
}
public float getNoOfStdSMS() {
	return noOfStdSMS;
}
public void setNoOfStdSMS(int noOfStdSMS) {
	this.noOfStdSMS = noOfStdSMS;
}
public float getNoOfLocalCalls() {
	return noOfLocalCalls;
}
public void setNoOfLocalCalls(int noOfLocalCalls) {
	this.noOfLocalCalls = noOfLocalCalls;
}
public float getNoOfStdCalls() {
	return noOfStdCalls;
}
public void setNoOfStdCalls(int noOfStdCalls) {
	this.noOfStdCalls = noOfStdCalls;
}
public float getInternetDataUsageUnits() {
	return internetDataUsageUnits;
}
public void setInternetDataUsageUnits(float internetDataUsageUnits) {
	this.internetDataUsageUnits = internetDataUsageUnits;
}
public float getInternetDataUsageUnitsAmount() {
	return internetDataUsageUnitsAmount;
}
public void setInternetDataUsageUnitsAmount(float internetDataUsageUnitsAmount) {
	this.internetDataUsageUnitsAmount = internetDataUsageUnitsAmount;
}
public float getBillMonth() {
	return billMonth;
}
public void setBillMonth(float billMonth) {
	this.billMonth = billMonth;
}
public float getStateGST() {
	return stateGST;
}
public void setStateGST(float stateGST) {
	this.stateGST = stateGST;
}
public float getCentralGST() {
	return centralGST;
}
public void setCentralGST(float centralGST) {
	this.centralGST = centralGST;
}
public float getTotalBillAmount() {
	return totalBillAmount;
}
public void setTotalBillAmount(float totalBillAmount) {
	this.totalBillAmount = totalBillAmount;
}
public float getLocalSMSAount() {
	return localSMSAount;
}
public void setLocalSMSAount(float localSMSAount) {
	this.localSMSAount = localSMSAount;
}
public float getStdSMSAmount() {
	return stdSMSAmount;
}
public void setStdSMSAmount(float stdSMSAmount) {
	this.stdSMSAmount = stdSMSAmount;
}
public float getTotalCallAmount() {
	return totalCallAmount;
}
public void setTotalCallAmount(float totalCallAmount) {
	this.totalCallAmount = totalCallAmount;
}

}