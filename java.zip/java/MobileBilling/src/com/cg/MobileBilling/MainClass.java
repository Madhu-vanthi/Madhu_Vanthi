package com.cg.MobileBilling;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
