package com.cg.calculator.exception;

public class InvalidNumberRangeException extends Exception{

	public InvalidNumberRangeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidNumberRangeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidNumberRangeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidNumberRangeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidNumberRangeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
