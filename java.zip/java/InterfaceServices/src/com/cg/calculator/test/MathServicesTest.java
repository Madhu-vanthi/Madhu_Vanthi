package com.cg.calculator.test;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.calculator.exception.InvalidNumberRangeException;
import com.cg.calculator.services.MathServices;
import com.cg.calculator.services.MathServicesImpl;

public class MathServicesTest {
private static MathServices mathServices;
private int firstInvalidNumber,secondInvalidNumber,firstValidNumber,secondValidNumber;
@BeforeClass
public static void setUptestEnv() {
	mathServices=new MathServicesImpl();
	
}
@Before
public void setUpTestDate() {
	firstInvalidNumber=-100;
	firstValidNumber=100;
	secondInvalidNumber=-200;
	secondValidNumber=200;
}
@Test(expected=InvalidNumberRangeException.class)
public void testAddForFirstNumber()throws InvalidNumberRangeException{
	mathServices.add(firstInvalidNumber, secondInvalidNumber);
}

@Test(expected=InvalidNumberRangeException.class)
public void testAddForSecondNumber()throws InvalidNumberRangeException{
	mathServices.add(firstInvalidNumber, secondInvalidNumber);
}
public void testAddForBothValidNumber()throws InvalidNumberRangeException{
	int expectedAns=300;
	int actualAns=mathServices.add(firstValidNumber, secondValidNumber);
	Assert.assertEquals(expectedAns,actualAns);
}
//subtraction
@Test(expected=InvalidNumberRangeException.class)
public void testSubForFirstNumber()throws InvalidNumberRangeException{
	mathServices.sub(firstInvalidNumber, secondInvalidNumber);
}

@Test(expected=InvalidNumberRangeException.class)
public void testSubForSecondNumber()throws InvalidNumberRangeException{
	mathServices.sub(firstInvalidNumber, secondInvalidNumber);
}
public void testSubForBothValidNumber()throws InvalidNumberRangeException{
	int expectedAns=-100;
	int actualAns=mathServices.sub(firstValidNumber, secondValidNumber);
	Assert.assertEquals(expectedAns,actualAns);
}

//multiplication
@Test(expected=InvalidNumberRangeException.class)
public void testMulForFirstNumber()throws InvalidNumberRangeException{
	mathServices.mul(firstInvalidNumber, secondInvalidNumber);
}

@Test(expected=InvalidNumberRangeException.class)
public void testMulForSecondNumber()throws InvalidNumberRangeException{
	mathServices.mul(firstInvalidNumber, secondInvalidNumber);
}
public void testMulForBothValidNumber()throws InvalidNumberRangeException{
	int expectedAns=20000;
	int actualAns=mathServices.mul(firstValidNumber, secondValidNumber);
	Assert.assertEquals(expectedAns,actualAns);
}
//division
@Test(expected=InvalidNumberRangeException.class)
public void testDivForFirstNumber()throws InvalidNumberRangeException{
	mathServices.div(firstInvalidNumber, secondInvalidNumber);
}

@Test(expected=InvalidNumberRangeException.class)
public void testDivForSecondNumber()throws InvalidNumberRangeException{
	mathServices.div(firstInvalidNumber, secondInvalidNumber);
}
public void testDivForBothValidNumber()throws InvalidNumberRangeException{
	int expectedAns=0;
	int actualAns=mathServices.div(firstValidNumber, secondValidNumber);
	Assert.assertEquals(expectedAns,actualAns);
}
@AfterClass
public static void removeTestEnv() {
	mathServices=null;
}
}