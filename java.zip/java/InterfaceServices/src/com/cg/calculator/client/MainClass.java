package com.cg.calculator.client;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.calculator.exception.InvalidNumberRangeException;
import com.cg.calculator.services.MathServices;
import com.cg.calculator.services.MathServicesImpl;

public class MainClass {

	public static void main(String[] args) {
	MathServices math=new MathServicesImpl();
		Scanner s=new Scanner(System.in);
		try {
		System.out.println(math.add(100,200));
		System.out.println(math.sub(100,200));
		System.out.println(math.mul(100,200));
		System.out.println(math.div(100,200));
		}
		//int num1=100;
		//System.out.println("Enter second number");
		//int num2=200;
		//System.out.println("Answer:"+num1/num2);
		catch(InvalidNumberRangeException e1)
		{
			e1.printStackTrace();
		}
	}	
	}
