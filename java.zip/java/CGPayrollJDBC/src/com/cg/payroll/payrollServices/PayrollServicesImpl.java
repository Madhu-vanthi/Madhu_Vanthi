package com.cg.payroll.payrollServices;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;

public class PayrollServicesImpl implements PayrollServices {

	private AssociateDAO associateDAO=new AssociateDAOImpl();
	public PayrollServicesImpl() {
		associateDAO=new AssociateDAOImpl();
	}	
	public PayrollServicesImpl(AssociateDAO associateDAO) {
		super();
		this.associateDAO = associateDAO;
	}	

	@Override
	public int acceptAssociateDetails(int yearlyInvestmentUnder80C, String firstName, String lastName,
			 String designation,String department, String emailid, int basicSalary,int epf,int companyEpf,
			String accountNumber,String bankName, String ifscCode) {
		
	Associate associate=new Associate( yearlyInvestmentUnder80C,  firstName,  lastName,
			  designation, department,  emailid, new Salary( basicSalary, epf, companyEpf),new 
			  BankDetails( accountNumber,bankName,  ifscCode ));
	associate=associateDAO.save(associate);
		return associate.getAssociateId();
	}

	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=this.getAssociateDetails(associateId);
		associate.getSalary().setHra((40/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setConveyenceAllowance((30/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setPersonalAllowance((20/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setGrossSalary((20/100)*associate.getSalary().getBasicSalary());
		
		associate.getSalary().setGrossSalary((associate.getSalary().getBasicSalary()+associate.getSalary().getCompanyPf()+
				associate.getSalary().getConveyenceAllowance()+associate.getSalary().getEpf()+associate.getSalary().getHra()+
				associate.getSalary().getOtherAllowance()+associate.getSalary().getPersonalAllowance())*12);
		int tax=associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()-associate.getSalary()
				.getCompanyPf()*12-associate.getSalary().getEpf()*12;
		if(tax>0&&tax<=250000)
			associate.getSalary().setMonthlyTax(0);
		else if(tax>25000&&tax<=500000)
			associate.getSalary().setMonthlyTax((associate.getSalary().getGrossSalary()/12)/10);
		else if(tax>500000&&tax<1000000)
			associate.getSalary().setMonthlyTax((((associate.getSalary().getGrossSalary()/12)/10)*2)+30000);
		else 	
			associate.getSalary().setMonthlyTax((((associate.getSalary().getGrossSalary()/12)/10)*3)+130000);
		
		associate.getSalary().setNetSalary((associate.getSalary().getGrossSalary()/12)-associate.getSalary().getEpf()
				-associate.getSalary().getCompanyPf()-associate.getSalary().getMonthlyTax());
	
		return associate.getSalary().getNetSalary();
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDAO.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("AssociateId not found exception");
			return associate;
	}

	@Override
	public List<Associate> getAllAssociateDetails() {
		// TODO Auto-generated method stub
		return associateDAO.findAll();
	}

}







/*package com.cg.payroll.client;

import java.util.Scanner;

import com.cg.payroll.beans.Associate;
//import com.cg.payroll.beans.*;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.services.*;

public class MainClass {
    public static void main(String[] args) throws AssociateDetailsNotFoundException {
        //object to link or communicate with payroll services
        PayrollServices payrollServices=new PayrollServicesImpl();
        Scanner scanner=new Scanner(System.in);
        int choice = 0,associateId;
        System.out.println("Associate Management System");
        do {
            System.out.println(
                    "___________________\nPlease enter ur choice : \n1. Add associate\n2. Find associate\n3. Calculate salary\n4. Display all assocciates\n5. Exit\n___________________");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
            case 1:
                System.out.println("Enter new associate details : ");
                System.out.println("First Name : ");
                String firstName = scanner.nextLine();
                System.out.println("Last Name : ");
                String lastName = scanner.nextLine();
                System.out.println("Department : ");
                String department = scanner.nextLine();
                System.out.println("Designation : ");
                String designation = scanner.nextLine();
                System.out.println("Pancard no. : ");
                String pancard = scanner.nextLine();
                System.out.println("Email Id : ");
                String emailId = scanner.nextLine();
                System.out.println("Basic Salary : ");
                int basicSalary = scanner.nextInt();
                System.out.println("EPF Amount : ");
                int epf = scanner.nextInt();
                System.out.println("Company PF Amount :");
                int companyPf = scanner.nextInt();
                System.out.println("Yearly Investment Under 80C : ");
                int yearlyInvestmentUnder80C = scanner.nextInt();
                System.out.println("Bank Account no. :");
                int accountNumber = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Bank Name : ");
                String bankName = scanner.next();
                System.out.println("Bank IFSC Code : ");
                String ifscCode = scanner.next();
                associateId = payrollServices.acceptAssociateDetails(yearlyInvestmentUnder80C, firstName, lastName, department,
                        designation, pancard, emailId, basicSalary, epf, companyPf, accountNumber, bankName, ifscCode);
                break;

            case 2:
                System.out.println("Enter Associate Id to search");
                associateId = scanner.nextInt();
                try {
                    System.out.println(
                            "Associate details : \n" + payrollServices.getAssociateDetails(associateId).toString());
                } catch (AssociateDetailsNotFoundException e) {
                    e.printStackTrace();
                }
                break;

            case 3:
                System.out.println("Enter Associate Id to search");
                associateId = scanner.nextInt();
                try {
                    System.out.println("Associate salary : " + payrollServices.calculateNetSalary(associateId));
                } catch (AssociateDetailsNotFoundException e) {
                    e.printStackTrace();
                }
                break;

            case 4:
                System.out.println("All Associate Details");
                Associate[] associates = payrollServices.getAllAssociateDetails();
                try {
                    for (Associate associate : associates)
                        if (associate != null)
                            System.out.println("___________________________________________\n"
                                    + payrollServices.getAssociateDetails(associate.getAssociateId()).toString());
                } catch (AssociateDetailsNotFoundException e) {
                    e.printStackTrace();
                }
                break;

            case 5:
                System.out.println("Exited");
                System.exit(0);

            default:
                System.out.println("Invalid Choice...");
                break;
            }
        } while (choice != 5);
    }
}
 */
