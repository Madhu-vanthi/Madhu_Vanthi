package com.cg.payroll.test;

import java.util.ArrayList;


import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.payrollServices.PayrollServices;



public class PayrollServicesTestEasyMock {
/*private static PayrollServices payrollServices;
private static AssociateDAO mockAssociateDAO;

@BeforeClass
public static void setUpTestEnv() {
	mockAssociateDAO=EasyMock.mock(AssociateDAO.class);
}
@Before
public void setUpTestMockData() {
	Associate associate1=new Associate(101,78000,"Madhu","m","Analyst","a4",
			"madhu@gmail.com",new Salary(35000,1800,1800),	new BankDetails("12345","HDFC","HDFC6372"));
	Associate associate2=new Associate(101,78000,"Madhu","m","Analyst","a4",
			"madhu@gmail.com",new Salary(35000,1800,1800),
			new BankDetails("12345","HDFC","HDFC6372"));
	Associate associate3=new Associate(101,78000,"Madhu","m","Analyst","a4",
			"madhu@gmail.com",new Salary(35000,1800,1800),
			new BankDetails("12345","HDFC","HDFC6372"));
ArrayList<Associate> associatesList=new ArrayList<>();
associatesList.add(associate1);
associatesList.add(associate2);
EasyMock.expect(mockAssociateDAO.save(associate3)).andReturn(associate3);

EasyMock.expect(mockAssociateDAO.findOne(101)).andReturn(associate3);
EasyMock.expect(mockAssociateDAO.findOne(102)).andReturn(associate3);
EasyMock.expect(mockAssociateDAO.findOne(1025)).andReturn(null);
EasyMock.expect(mockAssociateDAO.findAll()).andReturn(associatesList);
}
@Test(expected=AssociateDetailsNotFoundException.class)
public void testGetAssociateDataForInvalidAsociateId() throws AssociateDetailsNotFoundException{
payrollServices.getAssociateDetails(123);
EasyMock.verify(mockAssociateDAO.findOne(123));
}
@Test
public void testGetAssociateDataForValidAssociateId()throws AssociateDetailsNotFoundException{
	Associate expectedAssociate=new Associate(101,78000,"Madhu","m","Analyst","a4",
			"madhu@gmail.com",new Salary(35000,1800,1800),	new BankDetails("12345","HDFC","HDFC6372"));
Associate actualAssociate=mockAssociateDAO.findOne(101);
Assert.assertEquals(expectedAssociate, mockAssociateDAO);
EasyMock.verify(mockAssociateDAO.findOne(101));
}
@Test(expected=AssociateDetailsNotFoundException.class)
public void testCalculateNetSalaryForInvalidAssociateId()throws AssociateDetailsNotFoundException{
	payrollServices.getAssociateDetails(250);
	EasyMock.verify(mockAssociateDAO.findOne(123));
}
@Test
public void testCalculateNetSalaryForValidAssociateId()throws AssociateDetailsNotFoundException{
	int expectedNetSalary=45866;
	int actualNetSalary=payrollServices.calculateNetSalary(101);
	EasyMock.verify(mockAssociateDAO.findOne(101));
	Assert.assertEquals(expectedNetSalary, actualNetSalary);
}
@Test
public void testForGetAllAssociateDetails() {
	 ArrayList<Associate> expectedAssociateList=new ArrayList<>(PayrollUtil.associates.values());
     ArrayList<Associate> actualAssociateList=(ArrayList<Associate>) payrollServices.getAllAssociateDetails();
     Assert.assertEquals(expectedAssociateList, actualAssociateList);
     EasyMock.verify(mockAssociateDAO.findAll());
     }
@After
public void tearDownTestData() {
	EasyMock.reset(mockAssociateDAO);
}
@AfterClass
public static void tearDownTestEnv() {
	mockAssociateDAO=null;
	payrollServices=null;
}*/
}
