package com.cg.payroll;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import com.cg.payroll.beans.*;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.payrollServices.PayrollServices;
import com.cg.payroll.payrollServices.PayrollServicesImpl;
import com.cg.payroll.util.DBUtil;

public class MainClass {	
	public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, IOException, SQLException {
	/*try {
		DBUtil.getDBConnection();	
			System.out.println("Connection open");
	} catch (ClassNotFoundException | IOException | SQLException e) {
		e.printStackTrace();}		
	*/
	}}
	/*	PayrollServices payrollServices=new PayrollServicesImpl();
		try {
	int associateID=payrollServices.acceptAssociateDetails( 541541, "madhu	"," m"," Devlopr", "A4", 
	"madhu@gmail.com", 252522,1000,2000 ,"90873902173", "HDFC", "hdfc145254");		
	System.out.println("AssociateId:"+associateID);
	Associate associate=payrollServices.getAssociateDetails(101);
	System.out.println("Associate Details : "+associate.toString());
		}
		catch(Exception e)
		{
		e.printStackTrace();
	}	try {
		System.out.println("Net salary is:"+payrollServices.calculateNetSalary(101));
	}catch(AssociateDetailsNotFoundException e)
	{
		e.printStackTrace();
	}	
	
	
	
	/*	Associate[] associates=new Associate[5];
}
		associates[0]=new Associate(11,300000,"Preethi","SR","Developer","Analyst","CNWP6744","preethi@gmail.com",new Salary(20200,1000,1000),new BankDetails("1001010101","HDFC","hdfc1919"));
		associates[1]=new Associate(11,300000,"madhu","S","FS Developer","Analyst","CVBFP6744","madhu@gmail.com",new Salary(50000,1000,1000),new BankDetails("101010101","HDFC","hdfc10010"));
		associates[2]=new Associate(12,30000,"lakshmi","M"," Developer","Analyst","CVFDDP6744","priya@gmail.com",new Salary(60000,2000,4000),new BankDetails("80868896","HDFC","hdfc09798"));
		associates[3]=new Associate(1,500000,"gopi","A"," Developer","Sr Analyst","CVBFP68562","preethi@gmail.com",new Salary(10000,1000,1000),new BankDetails("38778437","HDFC","hdfc00913"));
		associates[4]=new Associate(13,00000,"Aanchal","S","SF Developer","Sr Analyst","CVBFP68562","preethi@gmail.com",new Salary(10000,1000,1000),new BankDetails("83749384","HDFC","hdfc043"));
		for(Associate associate2:associates)
		{
			if(associate2.getSalary().getBasicSalary()>=20000&&associate2.getBankDetails().getBankName().equals("HDFC"))
			{
				System.out.println(associate2.getFirstName()+" "+associate2.getLastName()+" "
						+associate2.getDepartment());
			}}	}}
	/*for(int i=0;i<associates.length;i++)
		{
			if(associates[i].getAssociateId()==11)
			{
			System.out.println(associate.getFirstName()+" "+associate.getLastName()+" "
						+associate.getDepartment());	}}
	int associateId=12;
		for(Associate associate1:associates)
		{
			if(associate1.getAssociateId()==12)
			{		System.out.println(c	}}	*/

	