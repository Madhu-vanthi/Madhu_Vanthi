package com.cg.client;

import com.cg.bean.Animal;
import com.cg.bean.Cat;
import com.cg.bean.Dog;

public class MainClass {

	public static void main(String[] args){
	Animal A1=new Animal(false, 0, 4+" "+"Food"+"White", null);
	System.out.println(A1.isVeg()+" "+A1.getLegs()+" "+A1.getEats()+" "+A1.getColour());
	
	Cat c1=new Cat(true,0,0);
	System.out.println(A1.isVeg()+" "+A1.getLegs()+" "+A1.getEats()+" "+A1.getColour());

	Dog D1=new Dog();
	System.out.println(A1.isVeg()+" "+A1.getLegs()+" "+A1.getEats()+" "+A1.getColour());

	
	
	}

}
