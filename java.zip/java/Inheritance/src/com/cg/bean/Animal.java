package com.cg.bean;

public class Animal {
  
	private boolean veg;
	private int legs;
	private String eats,colour;
	
	public Animal(){
	}

	public Animal(boolean veg, int legs, String eats, String colour) {
		super();
		this.veg = veg;
		this.legs = legs;
		this.eats = eats;
		this.colour = colour;
	}

	public boolean isVeg() {
		return veg;
	}

	public void setVeg(boolean veg) {
		this.veg = veg;
	}

	public int getLegs() {
		return legs;
	}

	public void setLegs(int legs) {
		this.legs = legs;
	}

	public String getEats() {
		return eats;
	}

	public void setEats(String eats) {
		this.eats = eats;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	
	
	
	
	
}
