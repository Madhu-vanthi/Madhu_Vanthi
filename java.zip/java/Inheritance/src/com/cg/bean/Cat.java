package com.cg.bean;

public class Cat extends Animal {
	
	public Cat(boolean veg, int legs, String food,String colour) {
		super(veg, legs,food, colour);	
	}

	public Cat() {
	}

	public Cat(boolean b, int i, int j) {
		// TODO Auto-generated constructor stub
	}

	
}
