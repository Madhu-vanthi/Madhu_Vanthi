package com.cg.bean;

public class Dog extends Animal 
{
	private String breed;
	public Dog(boolean veg, int legs, String food,String colour) {
		super(veg,legs, food, colour);
		this.breed="german sheperd";
	}
	public Dog(String breed) {
		super();
		this.breed = breed;
	}
	public Dog() {
	}
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	
}
