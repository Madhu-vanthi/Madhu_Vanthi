package com.cg.bean;

public class Lion extends Animal {
	
	
	public Lion(boolean veg, int legs, String food,String colour) {
		super(veg,legs, food, colour);
		}
}
