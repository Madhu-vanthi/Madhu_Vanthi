package com.cg.payroll.payrollServices;

import java.util.List;

import com.cg.payroll.beans.*;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;

public interface PayrollServices {
	int acceptAssociateDetails(int yearlyInvestmentUnder80C, String firstName, String lastName, String designation,
			String department, String emailid, int basicSalary, int epf, int companyEpf, String accountNumber,
			String bankName, String ifscCode);


	 int calculateNetSalary(int associateId)throws AssociateDetailsNotFoundException;

Associate getAssociateDetails(int associateId)throws AssociateDetailsNotFoundException;

 List<Associate> getAllAssociateDetails();





}