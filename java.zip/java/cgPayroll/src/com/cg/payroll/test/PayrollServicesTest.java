package com.cg.payroll.test;

import java.util.ArrayList;


import org.junit.After;
import org.junit.AfterClass;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.beans.PayrollUtil;
import com.cg.payroll.payrollServices.PayrollServices;
import com.cg.payroll.payrollServices.PayrollServicesImpl;



public class PayrollServicesTest {
    
    static PayrollServices payrollServices;
    @BeforeClass
    public static void setUpTestEnv() {
         payrollServices=new PayrollServicesImpl();
    }
@Before
public void setUpTestData() {
    Associate associate1=new Associate(101,78000,"Madhu","m","Analyst","a4",
			"madhu@gmail.com",new Salary(35000,1800,1800),	new BankDetails("12345","HDFC","HDFC6372"));
	
    Associate associate2=new Associate(101,78000,"Madhu","m","Analyst","a4",
			"madhu@gmail.com",new Salary(35000,1800,1800),	new BankDetails("12345","HDFC","HDFC6372"));
	
    PayrollUtil.associates.put(associate1.getAssociateId(), associate1);
    PayrollUtil.associates.put(associate1.getAssociateId(), associate2);
    PayrollUtil.ASSOCIATE_ID_COUNTER=103;
}
@Test
public void testAcceptAssociateDetailsForValidData() {
    int expectedAssociateId=103;
    int actualAssociateId=payrollServices.acceptAssociateDetails(32000,"Lakshmi","manchu","lakshmi@gmail.com","ADM","Manager"
    		,30000,1800,1800,"64545","HDFC","HDFC4242");
	
Assert.assertEquals(expectedAssociateId, actualAssociateId);
}
@Test(expected=AssociateDetailsNotFoundException.class)
public void testGetAssociateDataForInvalidAssociateId()throws AssociateDetailsNotFoundException {
    payrollServices.getAssociateDetails(2124);
}
@Test
public void testGetAssociateDataForValidAssociateId()throws AssociateDetailsNotFoundException{
    Associate expectedAssociate=new Associate(101,78000,"Madhu","m","Analyst","a4",
			"madhu@gmail.com",new Salary(35000,1800,1800),	new BankDetails("12345","HDFC","HDFC6372"));
    Associate actualAssociate=payrollServices.getAssociateDetails(102);
    Assert.assertEquals(expectedAssociate, actualAssociate);
}
    @Test
    public void testCalcualteNetSalaryForvalidAssociateId()throws AssociateDetailsNotFoundException{
        float expectedNetSalary=38066.67f;
        float actualNetSalary=payrollServices.calculateNetSalary(102);
        Assert.assertEquals(expectedNetSalary, actualNetSalary, 1000);
    }
    @Test
    public void testForGetAllAssociateDetails() {
        ArrayList<Associate> expectedAssociateList=new ArrayList<>(PayrollUtil.associates.values());
        ArrayList<Associate> actualAssociateList=(ArrayList<Associate>) payrollServices.getAllAssociateDetails();
        Assert.assertEquals(expectedAssociateList, actualAssociateList);
    }
    @After
    public void tearDownTestData() {
        PayrollUtil.ASSOCIATE_ID_COUNTER=100;
        com.cg.payroll.beans.PayrollUtil.associates.clear();
    }
    
    @AfterClass
    public static void tearDownTestEnv() {
        payrollServices=null;
    }
    
}


    


