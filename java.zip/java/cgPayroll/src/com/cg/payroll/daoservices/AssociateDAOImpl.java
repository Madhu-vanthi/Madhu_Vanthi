package com.cg.payroll.daoservices;
import java.util.*;

import java.util.List;
import java.util.Set;

import com.cg.*;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.PayrollUtil;
public class AssociateDAOImpl implements AssociateDAO {

	@Override
	public Associate save(Associate associate) {
	associate.setAssociateId(PayrollUtil.getASSOCIATE_ID_COUNTER());
	PayrollUtil.associates.put(associate.getAssociateId(),associate);
		return associate;
	}

	@Override
	public boolean update(Associate associate) {
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public Associate findOne(int AssociateId) {
		/*for(Associate associate:PayrollUtil.associates)
			if(associate!=null&&associate.getAssociateId()==AssociateId)*/
		return PayrollUtil.associates.get(AssociateId);
		
	}
	@Override
	public List<Associate> findAll() {
		return new ArrayList<>(PayrollUtil.associates.values());
		
	/*	ArrayList<Associate> associateList=new ArrayList<>();
		Set<Integer> keySet=PayrollUtil.associates.keySet();
		for(Integer key:keySet)
		associateList.add(PayrollUtil.associates.get(key));	}*/
		
   /*ArrayList<Associate> associateList=new ArrayList<>(PayrollUtil.associates.values());
		return associateList;*/
	}
}
