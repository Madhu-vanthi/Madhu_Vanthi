package lamdaInterface;

public interface WorkService {
 void doSomeWork();
}
