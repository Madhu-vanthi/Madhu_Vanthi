package lamdaInterface;
@FunctionalInterface
public interface FunctionalInterface3 {
String uppercase(String str);
}
