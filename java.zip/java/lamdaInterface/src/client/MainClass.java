package client;

import lamdaInterface.FunctionalInterface1;
import lamdaInterface.FunctionalInterface2;
import lamdaInterface.FunctionalInterface3;
import lamdaInterface.WorkService;

public class MainClass {

	public static void main(String[] args) {
		  FunctionalInterface1 ref1 = (fName, lName) -> System.out.println(fName+" "+lName);
	        ref1.greetUser("madhu","vanthi");
				        
		        FunctionalInterface2 ref2 = (a,b)->a+b;
		        System.out.println(ref2.add(100,200));
		        
		        FunctionalInterface3 ref3 = (str) -> str.toUpperCase();
		        System.out.println(ref3.uppercase("hello world"));
		        
		        callForWork(() -> System.out.println("Doing Some Work"));
		        
		        /*Runnable r = ()->{
		        for(int i=0;i<10;i++)
		            System.out.println("Tick "+i);};        
		        Thread th1 = new Thread(r);
		        th1.start();    */
		    
		        /*Thread th2 = new Thread(()->{
		        for(int i=0;i<10;i++)
		            System.out.println("Tick "+i);});
		        th2.start();    */
		    
		        new Thread(()->{for(int i=0;i<10;i++)           
		                System.out.println("Tick "+i);}).start();
		        
		    }       
		        public static void callForWork(WorkService service) {
		            service.doSomeWork();
		}

	}

